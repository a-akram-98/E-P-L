#from .scn import RCNNSpMiddleFHD, SpMiddleFHD
from .scn_dense_4 import SpMiddleFHD

__all__ = ["SpMiddleFHD"]
