#from .mg_head import Head, MultiGroupHead, RegHead


from .mg_head_v4_release import Head, MultiGroupHead

__all__ = ["MultiGroupHead", "Head"]
