# Installation
1.complie
```
sudo python3 setup.py install
```

2.you can import in Python
```
import RotateRoIAlign_cuda
```

3.if you want to recompile, run clean.sh
```
bash clean.sh
```

4.check gradient
```
python3 grad_check.py
```

