pip uninstall RotateRoIAlign
rm -r build dist __pycache__ RotateRoIAlign.egg-info
python setup.py install
