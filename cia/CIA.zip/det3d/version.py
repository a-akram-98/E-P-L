# GENERATED VERSION FILE
# TIME: Wed Jul 29 15:22:16 2020
__version__ = '1.0.rc0+530c79c'
short_version = '1.0.rc0'
