from det3d.utils.registry import Registry

DATASETS = Registry("dataset")
PIPELINES = Registry("pipeline")
